SARAH-Plugin-runstop
====================

### Run, Stop and Restart S.A.R.A.H.


Plugin pour S.A.R.A.H. (http://www.encausse.net) qui permet, vocalement, d'arrêter définitivement ou de redémarrer complètement SARAH.
Il permet également d'utiliser les actions Arrêt/Démarrage/Redémarrage de manière autonome et indépendante de SARAH, directement à partir des scripts.


Egalement :
- Possibilité d'enchaîner des actions au démarrage de SARAH :
  - Affichage d'une site web
  - Lancement d'un exécutable
  - Lancement d'un plugin
  - Prononciation d'une phrase ...
- Possibilité de lancer le serveur (la console DOS) en mode minimisé ou non, caché ou non
- Possibilité de lancer aussi Log2Console (en mode minimisé ou non)
- Possibilité de fermer également Log2Console
- Possibilité de forcer ou non la fermeture de SARAH
- etc...﻿


#### ATTENTION
Bien lire la documentation détaillée fournie (index.html) accessible, une fois le plugin installé, via l'interface de SARAH en cliquant sur le Portlet "Run & Stop" !

